//
//  Item+CoreDataProperties.swift
//  0524
//
//  Created by jasmine on 2023/6/5.
//
//

import Foundation
import CoreData


extension GameRecord{

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Item> {
        return NSFetchRequest<Item>(entityName: "Item")
    }

    @NSManaged public var timestamp: Date?
    @NSManaged public var gameRecord: String?

}

extension  GameRecord: Identifiable {

}

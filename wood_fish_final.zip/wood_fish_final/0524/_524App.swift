//
//  _524App.swift
//  0524
//
//  Created by stu-29 on 2023/5/24.
//

import SwiftUI

@main
struct _524App: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
   WindowGroup {
  MainView()
 .environment(\.managedObjectContext, persistenceController.container.viewContext)
   }
    }
}

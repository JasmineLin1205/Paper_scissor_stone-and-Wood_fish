import SwiftUI
import CoreData

extension Color {
    init(hex: UInt32) {
        let red = Double((hex >> 16) & 0xFF) / 255.0
        let green = Double((hex >> 8) & 0xFF) / 255.0
        let blue = Double(hex & 0xFF) / 255.0
        self.init(red: red, green: green, blue: blue)
    }
}

enum Hand: Int {
    case stone = 0
    case paper = 1
    case scissors = 2
}

struct MainView: View {
    @State private var showGame = false
    @State private var showGame1 = false
    @State private var showGameHistory = false
    @State private var showWoodHistory = false

    var body: some View {
            ZStack{
                Color(hex: 0xEDF5EB)
                    .ignoresSafeArea()
                VStack {
                    Text("請選擇遊戲")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(Color(hex: 0x535753))
                    Spacer()
                    Image("wf2")
                        .resizable()
                        .frame(width: 110, height: 110)
                        .cornerRadius(15)
                    HStack{
                        Button(action: {
                            showGame = true
                        }) {
                            Text("木魚遊戲")
                                .font(.title)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color(hex: 0x646964))
                                .cornerRadius(10)
                        }
                        /*Button(action: {
                            showWoodHistory = true
                        }) {
                            Text("歷史紀錄")
                                .font(.title)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color(hex: 0x909990))
                                .cornerRadius(10)
                        }*/
                    }
                    Spacer()
                    Image("stone_pic")
                        .resizable()
                        .frame(width: 110, height: 110)
                        .cornerRadius(25)
                    HStack{
                        Button(action: {
                            showGame1 = true
                        }) {
                            Text("猜拳遊戲")
                                .font(.title)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color(hex: 0x646964))
                                .cornerRadius(10)
                        }
                        Button(action: {
                            showGameHistory = true
                        }) {
                            Text("歷史紀錄")
                                .font(.title)
                                .foregroundColor(.white)
                                .padding()
                                .background(Color(hex: 0x909990))
                                .cornerRadius(10)
                        }
                    }
                    Spacer()
                }
            
            
                //.navigationBarHidden(ture)
                .sheet(isPresented: $showGame) {
                    ContentView()
                        .navigationBarItems(leading: backButton)
                }
                .sheet(isPresented: $showGame1) {
                    ContentView1()
                        .navigationBarItems(leading: backButton)
                }
                .sheet(isPresented: $showGameHistory) {
                    GameHistoryView()
                        .navigationBarItems(leading: backButton)
                }
                .sheet(isPresented: $showWoodHistory) {
                    WoodHistoryView()
                        .navigationBarItems(leading: backButton)
                }
            
        }
    }
    private var backButton: some View {
        Button(action: {
            showGame = false
            showGame1 = false
        }) {
            Image(systemName: "chevron.left")
                .foregroundColor(.white)
        }
    }
}

struct WoodHistoryView: View {
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Woodfish.time, ascending: true)],
        animation: .default)
    private var woodfishs: FetchedResults<Woodfish>
    
    var body: some View {
            VStack {
                Text("Game History")
                    .font(.largeTitle)
                    .padding()
                
                List {
                    ForEach(woodfishs) { woodfish in
                        VStack {
                            Text(woodfish.time!, formatter: woodFormatter)
                            Text(woodfish.scorenumber ?? "")
                        }
                    }
                }
            }
    }
    
}

struct GameHistoryView: View {
    @Environment(\.managedObjectContext) private var viewContext
        @FetchRequest(
            sortDescriptors: [NSSortDescriptor(keyPath: \Item.timestamp, ascending: true)],
            animation: .default)
        private var items: FetchedResults<Item>
    
    var body: some View {
        NavigationView {
            VStack {
                Text("Game History")
                    .font(.largeTitle)
                    .padding()
                List {
                    ForEach(items) { item in
                        
                        VStack {
                            Text(item.timestamp!, formatter: itemFormatter)
                            Text("\(item.record ?? "")")
                        }
                    }
                    .onDelete(perform: deleteItems)
                }
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        EditButton()
                    }
                }
            }
        }
    }
    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { items[$0] }.forEach(viewContext.delete)

            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }

}


private let woodFormatter: DateFormatter = {
     let formatter = DateFormatter()
     formatter.dateStyle = .short
     formatter.timeStyle = .medium
     return formatter
}()

private let itemFormatter: DateFormatter = {
     let formatter = DateFormatter()
     formatter.dateStyle = .short
     formatter.timeStyle = .medium
     return formatter
}()

struct ContentView: View { //木魚遊戲
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var score = 0
    @State private var showAlert = false
    @State private var timeRemaining = 10
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    //@Environment(\.presentationMode) var presentationMode
    

    var body: some View {
        VStack {
            Spacer()
            HStack {
                Text("時間: \(timeRemaining)")
                    .font(.largeTitle)
                    .foregroundColor(Color.white)
                    .padding()
                    .alignmentGuide(.trailing) { _ in
                        UIScreen.main.bounds.width - 20
                    }
                Spacer()
                Text("陰德: \(score)")
                    .font(.largeTitle)
                    .foregroundColor(Color.white)
                    .padding()
                    .alignmentGuide(.trailing) { _ in
                        UIScreen.main.bounds.width - 20
                    }
            }
            Spacer()
            Button(action: {
                score += 1
                //print(score)
            }) {
                Image("wf")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 300, height: 300)
                    .padding()
            }
            .foregroundColor(.white)
            .cornerRadius(10)
            
            Spacer()
        }
        
        .background(Color.black)
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Time out！"), message: Text("善哉善哉."), dismissButton: .default(Text("OK")))
        }
        
        .onReceive(timer) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
            } else {
                showAlert = true
                timer.upstream.connect().cancel()
            }
        }
    }
    
}


struct ContentView1: View { //猜拳遊戲
    @Environment(\.managedObjectContext) private var viewContext
    
    @State private var playerHand: Hand = .stone
    @State private var computerHand: Hand = .stone
    @State private var playerScore: Int = 0
    @State private var computerScore: Int = 0
    @State private var result: String = ""
    @State private var showAlert = false
    

    var body: some View {
        VStack {
            Spacer()
            
            Text("電腦出拳：")
                .font(.headline)
            
            Image(playerHandToImageName(computerHand))
                .resizable()
                .frame(width: 200, height: 200)
            
            Spacer()
            
            HStack{
                VStack{
                    Text("電腦得分：")
                        .font(.headline)
                    Text("\(computerScore)")
                        .font(.headline)
                }
                Spacer()
                Text(result)
                    .font(.headline)
                Spacer()
                VStack{
                    Text("玩家得分：")
                        .font(.headline)
                    Text("\(playerScore)")
                        .font(.headline)
                }
            }
            .padding(.horizontal)
            Spacer()

            Image(playerHandToImageName(playerHand))
                .resizable()
                .frame(width: 200, height: 200)
            
            Spacer()
            
            Text("請選擇您的出拳")
                .font(.headline)
            
            HStack {
                Button(action: {
                    self.playGame(playerHand: .stone)
                }) {
                    VStack {
                        Image("stone")
                            .resizable()
                            .frame(width: 80, height: 80)
                    }
                }
                
                Button(action: {
                    self.playGame(playerHand: .paper)
                }) {
                    VStack {
                        Image("paper")
                            .resizable()
                            .frame(width: 80, height: 80)
                    }
                }
                
                Button(action: {
                    self.playGame(playerHand: .scissors)
                }) {
                    VStack {
                        Image("scissor")
                            .resizable()
                            .frame(width: 80, height: 80)
                    }
                }
            }
            
        }
        //.background(Color(hex: 0xB0CBD4))
        .padding()
        .alert(isPresented: $showAlert) {
            Alert(
                title: Text("遊戲結果"),
                message: Text(result),
                dismissButton: .default(Text("重新開始")) {
                    // 在此處重置遊戲
                    addItem(viewContext: viewContext, result: result)
                    resetGame()
                    self.playerHand = .stone
                    self.computerHand = .stone
                }
            )
        }
}

    func playGame(playerHand: Hand) {
        let randomHand = Hand(rawValue: Int.random(in: 0...2))!
        
        self.playerHand = playerHand
        self.computerHand = randomHand
        let playerHandString = playerHandToString(playerHand)
        let randomHandString = playerHandToString(randomHand)

        var resultText = ""
        resultText += ""
        resultText += ""
        if playerHand == randomHand {
            resultText += "平局！"
        } else if (playerHand == .stone && randomHand == .scissors) ||
            (playerHand == .paper && randomHand == .stone) ||
            (playerHand == .scissors && randomHand == .paper) {
            resultText += ""
            playerScore += 1
        } else {
            resultText += ""
            computerScore += 1
        }

        if playerScore >= 2 || computerScore >= 2 {
            if playerScore > computerScore {
                resultText += "\n玩家獲得三戰兩勝！"
            } else {
                resultText += "\n電腦獲得三戰兩勝！"
            }
            showAlert = true
            //resetGame()
            
        }
        
        self.result = resultText
    }
    
    func playerHandToString(_ hand: Hand) -> String {
        switch hand {
        case .stone:
            return "石頭"
        case .paper:
            return "布"
        case .scissors:
            return "剪刀"
        }
    }
    
    func playerHandToImageName(_ hand: Hand) -> String {
        switch hand {
        case .stone:
            return "stone"
        case .paper:
            return "paper"
        case .scissors:
            return "scissor"
        }
    }
    func resetGame() {
        
        playerScore = 0
        computerScore = 0
        result = ""
    }
        
   /*func addItem(){
        // 保存遊戲紀錄到Core Data
        let gameRecord = GameRecord(context: viewContext.managedObjectContext)
        gameRecord.playerScore = Int16(playerScore)
        gameRecord.computerScore = Int16(computerScore)
        gameRecord.result = result
        //gameResult.date = Date()
        
        // 將圖像重置為預設的stone圖像
        /*DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
         self.playerHand = .stone
         self.computerHand = .stone*/
        
            //保存CoreData上下文
            do {
                try viewContext.save()
            } catch {
                // 處理錯誤
                print("保存遊戲紀錄失敗：\(error)")
            }
        //}
    }*/
}


struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView().environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}

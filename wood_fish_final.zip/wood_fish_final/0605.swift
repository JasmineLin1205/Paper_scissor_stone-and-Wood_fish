//
//  0605.swift
//  0524
//
//  Created by jasmine on 2023/6/5.
//

import Foundation
import CoreData

func addItem(viewContext: NSManagedObjectContext, result: String) {
        let newItem = Item(context: viewContext)
        newItem.timestamp = Date()
        newItem.record = result

        do {
            try viewContext.save()
            //print("Item saved successfully")
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
        }
}

//
//  Item+CoreDataClass.swift
//  0524
//
//  Created by jasmine on 2023/6/5.
//
//

import Foundation
import CoreData

@objc(Item)
public class Item: NSManagedObject {

}

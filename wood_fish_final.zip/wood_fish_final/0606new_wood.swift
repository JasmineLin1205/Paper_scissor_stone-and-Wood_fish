//
//  0606new_wood.swift
//  0524
//
//  Created by jasmine on 2023/6/6.
//

import Foundation
import CoreData

func addWood(viewContext: NSManagedObjectContext, score: Int) {
        let newWood = Woodfish(context: viewContext)
        newWood.time = Date()
        newWood.scorenumber = String(score)
        print(score)
    
        do {
            try viewContext.save()
            print("Woodfish saved successfully")
        } catch {
            let nsError = error as NSError
            fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            //print("Failed to save Woodfish: \(nsError), \(nsError.userInfo)")
        }
}

